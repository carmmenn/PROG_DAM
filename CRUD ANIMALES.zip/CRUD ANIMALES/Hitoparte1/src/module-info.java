/**
 * 
 */
/**
 * 
 */
module Hitoparte1 {
}